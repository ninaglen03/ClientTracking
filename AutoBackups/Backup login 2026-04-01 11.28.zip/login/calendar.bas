﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes
    #FullScreen: False
    #IncludeTitle: False
#End Region

Sub Process_Globals
	Private tmrSlide As Timer
End Sub

Sub Globals
	'Must exist in your layout
	Private Panel6 As Panel
	Private Panel2 As Panel

	'Optional bottom nav labels (remove if not in your layout)
	Private lblDashboard As Label
	Private lblCalendar As Label
	Private lblToDo As Label
	Private lblNotifs As Label

	'Top sliding calendar
	Private lblYear As Label
	Private lblMonth As Label
	Private pnlWeekHost As Panel
	Private pnlWeekPrev As Panel
	Private pnlWeekCenter As Panel
	Private pnlWeekNext As Panel

	'Bottom activities
	Private svActivities As ScrollView

	'State
	Private Events As List
	Private SelectedDateTicks As Long
	Private CurrentWeekStart As Long

	'Swipe state
	Private TouchStartX As Float
	Private TouchStartY As Float
	Private IsDragging As Boolean
	Private IsAnimating As Boolean
	Private SlideDirection As Int ' -1 previous week, +1 next week
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("calendar")

	InitTopCalendarUI
	InitBottomActivitiesUI

	CurrentWeekStart = StartOfWeek(DateTime.Now)
	SelectedDateTicks = DateTime.Now

	If lblCalendar.IsInitialized Then
		ResetNavColors
		lblCalendar.TextColor = Colors.RGB(33, 120, 255)
	End If

	tmrSlide.Initialize("tmrSlide", 230)
End Sub

Sub Activity_Resume
	LoadEventsFromAppState
	RenderWeekTriplet
	RenderActivitiesForSelectedDate
End Sub

Sub Activity_Pause (UserClosed As Boolean)
End Sub

Private Sub InitTopCalendarUI
	Panel6.RemoveAllViews

	lblYear.Initialize("")
	lblYear.TextSize = 14
	lblYear.TextColor = Colors.RGB(120, 120, 120)
	Panel6.AddView(lblYear, 12dip, 8dip, 90dip, 20dip)

	lblMonth.Initialize("")
	lblMonth.TextSize = 24
	lblMonth.TextColor = Colors.Black
	Panel6.AddView(lblMonth, 12dip, 28dip, 180dip, 34dip)

	pnlWeekHost.Initialize("")
	Panel6.AddView(pnlWeekHost, 0, 70dip, Panel6.Width * 3, Panel6.Height - 74dip)

	pnlWeekPrev.Initialize("")
	pnlWeekCenter.Initialize("")
	pnlWeekNext.Initialize("")

	pnlWeekHost.AddView(pnlWeekPrev, 0, 0, Panel6.Width, pnlWeekHost.Height)
	pnlWeekHost.AddView(pnlWeekCenter, Panel6.Width, 0, Panel6.Width, pnlWeekHost.Height)
	pnlWeekHost.AddView(pnlWeekNext, Panel6.Width * 2, 0, Panel6.Width, pnlWeekHost.Height)

	pnlWeekHost.Left = -Panel6.Width
End Sub

Private Sub InitBottomActivitiesUI
	Panel2.RemoveAllViews

	svActivities.Initialize(0)
	Panel2.AddView(svActivities, 0, 0, Panel2.Width, Panel2.Height)
	svActivities.Color = Colors.Transparent
End Sub

Private Sub LoadEventsFromAppState
	Events = AppState.GetTaskEvents
	If Events.IsInitialized = False Then
		Events.Initialize
	End If
End Sub

Private Sub RenderWeekTriplet
	Dim centerStart As Long = CurrentWeekStart
	Dim prevStart As Long = centerStart - 7 * DateTime.TicksPerDay
	Dim nextStart As Long = centerStart + 7 * DateTime.TicksPerDay

	RenderWeekPanel(pnlWeekPrev, prevStart)
	RenderWeekPanel(pnlWeekCenter, centerStart)
	RenderWeekPanel(pnlWeekNext, nextStart)

	lblYear.Text = DateTime.GetYear(SelectedDateTicks)
	lblMonth.Text = MonthName(DateTime.GetMonth(SelectedDateTicks))
End Sub

Private Sub RenderWeekPanel(target As Panel, weekStart As Long)
	target.RemoveAllViews

	Dim dayNames() As String = Array As String("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
	Dim colW As Int = target.Width / 7

	For i = 0 To 6
		Dim dayTicks As Long = weekStart + (i * DateTime.TicksPerDay)

		Dim lblName As Label
		lblName.Initialize("")
		lblName.Text = dayNames(i)
		lblName.TextSize = 12
		lblName.TextColor = Colors.RGB(130, 130, 130)
		lblName.Gravity = Gravity.CENTER
		target.AddView(lblName, i * colW, 0, colW, 20dip)

		Dim lblDay As Label
		lblDay.Initialize("dayCell")
		lblDay.Tag = dayTicks
		lblDay.Text = DateTime.GetDayOfMonth(dayTicks)
		lblDay.TextSize = 16
		lblDay.Gravity = Gravity.CENTER

		If IsSameDate(dayTicks, SelectedDateTicks) Then
			lblDay.Color = Colors.RGB(33, 120, 255)
			lblDay.TextColor = Colors.White
		Else
			lblDay.Color = Colors.Transparent
			lblDay.TextColor = Colors.Black
		End If

		target.AddView(lblDay, i * colW + 8dip, 22dip, colW - 16dip, 34dip)

		If HasEventsOnDate(dayTicks) Then
			Dim dot As Label
			dot.Initialize("")
			dot.Text = "•"
			dot.TextColor = Colors.RGB(33, 120, 255)
			dot.Gravity = Gravity.CENTER
			target.AddView(dot, i * colW, 56dip, colW, 12dip)
		End If
	Next
End Sub

Private Sub RenderActivitiesForSelectedDate
	svActivities.Panel.RemoveAllViews

	Dim hdr As Label
	hdr.Initialize("")
	hdr.Text = "Activities for " & MonthName(DateTime.GetMonth(SelectedDateTicks)) & " " & DateTime.GetDayOfMonth(SelectedDateTicks) & ", " & DateTime.GetYear(SelectedDateTicks)
	hdr.TextSize = 18
	hdr.TextColor = Colors.Black
	svActivities.Panel.AddView(hdr, 12dip, 10dip, svActivities.Width - 24dip, 28dip)

	Dim topPos As Int = 44dip
	Dim found As Int = 0

	For i = 0 To Events.Size - 1
		Dim ev As Map = Events.Get(i)

		Dim dueTicks As Long = GetMapLong(ev, "due_ticks", 0)
		Dim taskName As String = GetMapString(ev, "task_name", "Task")
		Dim status As String = NormalizeStatus(GetMapString(ev, "status", "Pending"))

		If dueTicks > 0 And IsSameDate(dueTicks, SelectedDateTicks) Then
			found = found + 1

			Dim row As Panel
			row.Initialize("")
			row.Color = Colors.RGB(248, 248, 248)
			svActivities.Panel.AddView(row, 10dip, topPos, svActivities.Width - 20dip, 54dip)

			Dim lblTask As Label
			lblTask.Initialize("")
			lblTask.Text = taskName
			lblTask.TextSize = 15
			lblTask.TextColor = Colors.Black
			row.AddView(lblTask, 10dip, 8dip, row.Width - 110dip, 20dip)

			Dim lblStatus As Label
			lblStatus.Initialize("")
			lblStatus.Text = status
			lblStatus.TextSize = 13
			lblStatus.TextColor = StatusColor(status)
			lblStatus.Gravity = Gravity.RIGHT + Gravity.CENTER_VERTICAL
			row.AddView(lblStatus, row.Width - 95dip, 14dip, 85dip, 24dip)

			topPos = topPos + 62dip
		End If
	Next

	If found = 0 Then
		Dim emptyLbl As Label
		emptyLbl.Initialize("")
		emptyLbl.Text = "No activities for this day."
		emptyLbl.TextSize = 16
		emptyLbl.TextColor = Colors.Gray
		svActivities.Panel.AddView(emptyLbl, 12dip, topPos, svActivities.Width - 24dip, 26dip)
		topPos = topPos + 34dip
	End If

	svActivities.Panel.Height = Max(topPos + 10dip, svActivities.Height + 1dip)
End Sub

Private Sub dayCell_Click
	Dim l As Label = Sender
	SelectedDateTicks = l.Tag
	RenderWeekTriplet
	RenderActivitiesForSelectedDate
End Sub

Private Sub Panel6_Touch (Action As Int, X As Float, Y As Float)
	If IsAnimating Then Return

	Dim a As Int = Bit.And(Action, 0xFF)

	Select a
		Case Activity.ACTION_DOWN
			IsDragging = True
			TouchStartX = X
			TouchStartY = Y

		Case Activity.ACTION_UP
			If IsDragging = False Then Return
			IsDragging = False

			Dim dx As Float = X - TouchStartX
			Dim dy As Float = Y - TouchStartY

			If Abs(dx) > 60dip And Abs(dx) > Abs(dy) Then
				If dx < 0 Then
					StartSlide(1)   'next week
				Else
					StartSlide(-1)  'previous week
				End If
			End If
	End Select
End Sub

Private Sub StartSlide(direction As Int)
	If IsAnimating Then Return

	IsAnimating = True
	SlideDirection = direction

	If direction = 1 Then
		pnlWeekHost.SetLayoutAnimated(220, -Panel6.Width * 2, pnlWeekHost.Top, pnlWeekHost.Width, pnlWeekHost.Height)
	Else
		pnlWeekHost.SetLayoutAnimated(220, 0, pnlWeekHost.Top, pnlWeekHost.Width, pnlWeekHost.Height)
	End If

	tmrSlide.Enabled = True
End Sub

Private Sub tmrSlide_Tick
	tmrSlide.Enabled = False

	If SlideDirection = 1 Then
		CurrentWeekStart = CurrentWeekStart + (7 * DateTime.TicksPerDay)
	Else
		CurrentWeekStart = CurrentWeekStart - (7 * DateTime.TicksPerDay)
	End If

	SelectedDateTicks = CurrentWeekStart
	pnlWeekHost.Left = -Panel6.Width

	RenderWeekTriplet
	RenderActivitiesForSelectedDate

	IsAnimating = False
End Sub

Private Sub HasEventsOnDate(t As Long) As Boolean
	For i = 0 To Events.Size - 1
		Dim ev As Map = Events.Get(i)
		Dim dueTicks As Long = GetMapLong(ev, "due_ticks", 0)
		If dueTicks > 0 And IsSameDate(dueTicks, t) Then Return True
	Next
	Return False
End Sub

Private Sub NormalizeStatus(v As String) As String
	Dim s As String = v.Trim.ToLowerCase
	Select s
		Case "success", "done"
			Return "Success"
		Case "pending", "todo", "to do"
			Return "Pending"
		Case "delayed"
			Return "Delayed"
		Case "in progress", "doing"
			Return "In progress"
		Case Else
			Return "Pending"
	End Select
End Sub

Private Sub StatusColor(status As String) As Int
	Select status
		Case "Success"
			Return Colors.RGB(46, 125, 50)
		Case "Pending"
			Return Colors.RGB(240, 170, 0)
		Case "Delayed"
			Return Colors.RGB(244, 67, 54)
		Case "In progress"
			Return Colors.RGB(33, 120, 255)
		Case Else
			Return Colors.Gray
	End Select
End Sub

Private Sub MonthName(m As Int) As String
	Select m
		Case 1
			Return "January"
		Case 2
			Return "February"
		Case 3
			Return "March"
		Case 4
			Return "April"
		Case 5
			Return "May"
		Case 6
			Return "June"
		Case 7
			Return "July"
		Case 8
			Return "August"
		Case 9
			Return "September"
		Case 10
			Return "October"
		Case 11
			Return "November"
		Case 12
			Return "December"
		Case Else
			Return ""
	End Select
End Sub

Private Sub StartOfWeek(t As Long) As Long
	Dim dow As Int = DateTime.GetDayOfWeek(t) '1=Sunday
	Dim delta As Int = dow - 1
	Return (t - (delta * DateTime.TicksPerDay))
End Sub

Private Sub IsSameDate(a As Long, b As Long) As Boolean
	Return DateTime.GetYear(a) = DateTime.GetYear(b) _
        And DateTime.GetMonth(a) = DateTime.GetMonth(b) _
        And DateTime.GetDayOfMonth(a) = DateTime.GetDayOfMonth(b)
End Sub

Private Sub GetMapString(m As Map, key As String, defaultValue As String) As String
	If m.ContainsKey(key) Then Return "" & m.Get(key)
	Return defaultValue
End Sub

Private Sub GetMapLong(m As Map, key As String, defaultValue As Long) As Long
	If m.ContainsKey(key) = False Then Return defaultValue
	Try
		Return m.Get(key)
	Catch
		Return defaultValue
	End Try
End Sub

Private Sub lblDashboard_Click
	StartActivity(dashboard)
End Sub

Private Sub lblToDo_Click
	StartActivity(todo)
End Sub

Private Sub lblNotifs_Click
	StartActivity(notifs)
End Sub

Private Sub lblCalendar_Click
End Sub

Sub ResetNavColors
	If lblDashboard.IsInitialized Then lblDashboard.TextColor = Colors.Gray
	If lblCalendar.IsInitialized Then lblCalendar.TextColor = Colors.Gray
	If lblToDo.IsInitialized Then lblToDo.TextColor = Colors.Gray
	If lblNotifs.IsInitialized Then lblNotifs.TextColor = Colors.Gray
End Sub