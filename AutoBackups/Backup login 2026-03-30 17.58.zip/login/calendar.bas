﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes
    #FullScreen: False
    #IncludeTitle: False
#End Region

Sub Process_Globals
End Sub

Sub Globals
	Private Panel1 As Panel
	Private Panel2 As Panel

	Private lblDashboard As Label
	Private lblCalendar As Label
	Private lblToDo As Label
	Private lblNotifs As Label

	'Legacy labels from existing designer (kept so we can hide them)
	Private Label1 As Label
	Private Label2 As Label
	Private Label3 As Label
	Private Label4 As Label
	Private Label5 As Label
	Private Label6 As Label
	Private Label7 As Label
	Private Label8 As Label
	Private Label9 As Label
	Private Label10 As Label
	Private Label11 As Label
	Private Label12 As Label
	Private Label13 As Label
	Private Label14 As Label
	Private Label15 As Label
	Private Label16 As Label
	Private Label17 As Label
	Private Label18 As Label
	Private Label19 As Label
	Private Label20 As Label
	Private Label21 As Label

	'New runtime UI
	Private lblMonthTitle As Label
	Private btnPrev As Label
	Private btnNext As Label
	Private pnlWeekHeader As Panel
	Private pnlCalendarGrid As Panel
	Private svEvents As ScrollView

	Private chipSuccess As Label
	Private chipPending As Label
	Private chipDelayed As Label
	Private chipInProgress As Label

	Private ShowSuccess As Boolean = True
	Private ShowPending As Boolean = True
	Private ShowDelayed As Boolean = True
	Private ShowInProgress As Boolean = True

	Private CurrentMonthTicks As Long
	Private SelectedDateTicks As Long
	Private Events As List
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("calendar")

	ResetNavColors
	lblCalendar.TextColor = Colors.Blue

	HideLegacyViews
	InitCalendarUI
	InitFilterChips

	CurrentMonthTicks = StartOfMonth(DateTime.Now)
	SelectedDateTicks = DateTime.Now
End Sub

Sub Activity_Resume
	LoadEventsFromAppState
	RenderCalendar
	RenderEventsForSelectedDate
End Sub

Sub Activity_Pause (UserClosed As Boolean)
End Sub

Private Sub HideLegacyViews
	If Label2.IsInitialized Then Label2.Visible = False
	If Label3.IsInitialized Then Label3.Visible = False
	If Label4.IsInitialized Then Label4.Visible = False
	If Label5.IsInitialized Then Label5.Visible = False
	If Label6.IsInitialized Then Label6.Visible = False
	If Label7.IsInitialized Then Label7.Visible = False
	If Label8.IsInitialized Then Label8.Visible = False
	If Label9.IsInitialized Then Label9.Visible = False
	If Label10.IsInitialized Then Label10.Visible = False
	If Label11.IsInitialized Then Label11.Visible = False
	If Label12.IsInitialized Then Label12.Visible = False
	If Label13.IsInitialized Then Label13.Visible = False
	If Label14.IsInitialized Then Label14.Visible = False
	If Label15.IsInitialized Then Label15.Visible = False
	If Label16.IsInitialized Then Label16.Visible = False
	If Label17.IsInitialized Then Label17.Visible = False
	If Label18.IsInitialized Then Label18.Visible = False
	If Label19.IsInitialized Then Label19.Visible = False
	If Label20.IsInitialized Then Label20.Visible = False
	If Label21.IsInitialized Then Label21.Visible = False
End Sub

Private Sub InitCalendarUI
	'Header
	lblMonthTitle.Initialize("")
	lblMonthTitle.TextSize = 22
	lblMonthTitle.TextColor = Colors.Black
	lblMonthTitle.Gravity = Gravity.CENTER
	Panel1.AddView(lblMonthTitle, 52dip, 8dip, Panel1.Width - 104dip, 30dip)

	btnPrev.Initialize("btnPrev")
	btnPrev.Text = "<"
	btnPrev.TextSize = 20
	btnPrev.Gravity = Gravity.CENTER
	Panel1.AddView(btnPrev, 8dip, 8dip, 36dip, 30dip)

	btnNext.Initialize("btnNext")
	btnNext.Text = ">"
	btnNext.TextSize = 20
	btnNext.Gravity = Gravity.CENTER
	Panel1.AddView(btnNext, Panel1.Width - 44dip, 8dip, 36dip, 30dip)

	'Week header
	pnlWeekHeader.Initialize("")
	Panel1.AddView(pnlWeekHeader, 8dip, 44dip, Panel1.Width - 16dip, 24dip)

	Dim days() As String = Array As String("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
	Dim cellW As Int = pnlWeekHeader.Width / 7
	For i = 0 To 6
		Dim d As Label
		d.Initialize("")
		d.Text = days(i)
		d.TextColor = Colors.Gray
		d.TextSize = 14
		d.Gravity = Gravity.CENTER
		pnlWeekHeader.AddView(d, i * cellW, 0, cellW, pnlWeekHeader.Height)
	Next

	'Calendar grid
	pnlCalendarGrid.Initialize("")
	Panel1.AddView(pnlCalendarGrid, 8dip, 72dip, Panel1.Width - 16dip, Panel1.Height - 80dip)
	pnlCalendarGrid.Color = Colors.Transparent

	'Events list
	svEvents.Initialize(0)
	Panel2.AddView(svEvents, 8dip, 44dip, Panel2.Width - 16dip, Panel2.Height - 52dip)
End Sub

Private Sub InitFilterChips
	Dim chipTop As Int = 8dip
	Dim gap As Int = 6dip
	Dim available As Int = Panel2.Width - 16dip
	Dim chipW As Int = (available - (gap * 3)) / 4
	Dim left0 As Int = 8dip

	chipSuccess = AddFilterChip("chipSuccess", "Success", left0, chipTop, chipW, Colors.RGB(46, 125, 50))
	chipPending = AddFilterChip("chipPending", "Pending", chipSuccess.Left + chipW + gap, chipTop, chipW, Colors.RGB(240, 170, 0))
	chipDelayed = AddFilterChip("chipDelayed", "Delayed", chipPending.Left + chipW + gap, chipTop, chipW, Colors.RGB(244, 67, 54))
	chipInProgress = AddFilterChip("chipInProgress", "In progress", chipDelayed.Left + chipW + gap, chipTop, chipW, Colors.RGB(33, 120, 255))

	RefreshFilterChipStyles
End Sub

Private Sub AddFilterChip(EventName As String, caption As String, L As Int, T As Int, W As Int, c As Int) As Label
	Dim chip As Label
	chip.Initialize(EventName)
	chip.Text = caption
	chip.Tag = c
	chip.TextSize = 12
	chip.Gravity = Gravity.CENTER
	Panel2.AddView(chip, L, T, W, 28dip)
	Return chip
End Sub

Private Sub RefreshFilterChipStyles
	StyleChip(chipSuccess, ShowSuccess)
	StyleChip(chipPending, ShowPending)
	StyleChip(chipDelayed, ShowDelayed)
	StyleChip(chipInProgress, ShowInProgress)
End Sub

Private Sub StyleChip(chip As Label, enabled As Boolean)
	Dim c As Int = chip.Tag
	If enabled Then
		chip.Color = c
		chip.TextColor = Colors.White
	Else
		chip.Color = Colors.RGB(230, 230, 230)
		chip.TextColor = Colors.Gray
	End If
End Sub

Private Sub LoadEventsFromAppState
	Events = AppState.GetTaskEvents
	If Events.IsInitialized = False Then Events.Initialize
End Sub

Private Sub RenderCalendar
	pnlCalendarGrid.RemoveAllViews

	Dim y As Int = DateTime.GetYear(CurrentMonthTicks)
	Dim m As Int = DateTime.GetMonth(CurrentMonthTicks)
	lblMonthTitle.Text = MonthName(m) & " " & y

	Dim firstDay As Long = BuildDateTicks(y, m, 1)
	Dim firstDow As Int = DateTime.GetDayOfWeek(firstDay)
	Dim totalDays As Int = DaysInMonth(y, m)

	Dim cols As Int = 7
	Dim rows As Int = 6
	Dim cellW As Int = pnlCalendarGrid.Width / cols
	Dim cellH As Int = pnlCalendarGrid.Height / rows

	For d = 1 To totalDays
		Dim idx As Int = (firstDow - 1) + (d - 1)
		Dim r As Int = Floor(idx / cols)
		Dim c As Int = idx Mod cols

		Dim dayTicks As Long = BuildDateTicks(y, m, d)

		Dim dayLbl As Label
		dayLbl.Initialize("dayLbl")
		dayLbl.Text = d
		dayLbl.Tag = dayTicks
		dayLbl.Gravity = Gravity.CENTER
		dayLbl.TextSize = 14
		dayLbl.Color = Colors.Transparent
		dayLbl.TextColor = Colors.Black

		If IsSameDate(dayTicks, SelectedDateTicks) Then
			dayLbl.Color = Colors.RGB(33, 120, 255)
			dayLbl.TextColor = Colors.White
		Else If IsSameDate(dayTicks, DateTime.Now) Then
			dayLbl.Color = Colors.RGB(230, 238, 255)
			dayLbl.TextColor = Colors.RGB(33, 120, 255)
		End If

		pnlCalendarGrid.AddView(dayLbl, c * cellW + 1dip, r * cellH + 1dip, cellW - 2dip, cellH - 2dip)

		If HasVisibleEventsOnDate(dayTicks) Then
			Dim dot As Label
			dot.Initialize("")
			dot.Text = "•"
			dot.TextColor = Colors.RGB(33, 120, 255)
			dot.TextSize = 16
			dot.Gravity = Gravity.CENTER
			pnlCalendarGrid.AddView(dot, c * cellW + (cellW / 2) - 8dip, r * cellH + cellH - 16dip, 16dip, 12dip)
		End If
	Next
End Sub

Private Sub RenderEventsForSelectedDate
	svEvents.Panel.RemoveAllViews

	Dim y As Int = DateTime.GetYear(SelectedDateTicks)
	Dim m As Int = DateTime.GetMonth(SelectedDateTicks)
	Dim d As Int = DateTime.GetDayOfMonth(SelectedDateTicks)

	Dim hdr As Label
	hdr.Initialize("")
	hdr.Text = "Events for " & MonthName(m) & " " & d & ", " & y
	hdr.TextSize = 16
	hdr.TextColor = Colors.Black
	svEvents.Panel.AddView(hdr, 0, 0, svEvents.Width - 8dip, 28dip)

	Dim topPos As Int = 34dip
	Dim found As Int = 0

	For i = 0 To Events.Size - 1
		Dim ev As Map = Events.Get(i)
		Dim dueTicks As Long = GetMapLong(ev, "due_ticks", 0)
		Dim status As String = NormalizeStatus(GetMapString(ev, "status", "Pending"))
		Dim taskName As String = GetMapString(ev, "task_name", "Task")

		If dueTicks > 0 And IsSameDate(dueTicks, SelectedDateTicks) And IsStatusVisible(status) Then
			found = found + 1
			Dim row As Label
			row.Initialize("")
			row.Text = "• " & taskName & " (" & status & ")"
			row.TextColor = StatusColor(status)
			row.TextSize = 14
			svEvents.Panel.AddView(row, 0, topPos, svEvents.Width - 8dip, 26dip)
			topPos = topPos + 32dip
		End If
	Next

	If found = 0 Then
		Dim emptyLbl As Label
		emptyLbl.Initialize("")
		emptyLbl.Text = "No matching tasks for this day."
		emptyLbl.TextColor = Colors.Gray
		emptyLbl.TextSize = 14
		svEvents.Panel.AddView(emptyLbl, 0, topPos, svEvents.Width - 8dip, 26dip)
		topPos = topPos + 32dip
	End If

	If topPos < svEvents.Height Then topPos = svEvents.Height + 1dip
	svEvents.Panel.Height = topPos
End Sub

Private Sub IsStatusVisible(status As String) As Boolean
	Select status
		Case "Success"
			Return ShowSuccess
		Case "Pending"
			Return ShowPending
		Case "Delayed"
			Return ShowDelayed
		Case "In progress"
			Return ShowInProgress
		Case Else
			Return True
	End Select
End Sub

Private Sub HasVisibleEventsOnDate(dateTicks As Long) As Boolean
	For i = 0 To Events.Size - 1
		Dim ev As Map = Events.Get(i)
		Dim dueTicks As Long = GetMapLong(ev, "due_ticks", 0)
		Dim status As String = NormalizeStatus(GetMapString(ev, "status", "Pending"))
		If dueTicks > 0 And IsSameDate(dueTicks, dateTicks) And IsStatusVisible(status) Then Return True
	Next
	Return False
End Sub

Private Sub NormalizeStatus(v As String) As String
	Dim s As String = v.Trim.ToLowerCase
	Select s
		Case "success", "done"
			Return "Success"
		Case "pending", "todo", "to do"
			Return "Pending"
		Case "delayed"
			Return "Delayed"
		Case "in progress", "doing"
			Return "In progress"
		Case Else
			Return "Pending"
	End Select
End Sub

Private Sub StatusColor(s As String) As Int
	Select s
		Case "Success"
			Return Colors.RGB(46, 125, 50)
		Case "Pending"
			Return Colors.RGB(240, 170, 0)
		Case "Delayed"
			Return Colors.RGB(244, 67, 54)
		Case "In progress"
			Return Colors.RGB(33, 120, 255)
		Case Else
			Return Colors.Gray
	End Select
End Sub

Private Sub MonthName(m As Int) As String
	Select m
		Case 1 : Return "January"
		Case 2 : Return "February"
		Case 3 : Return "March"
		Case 4 : Return "April"
		Case 5 : Return "May"
		Case 6 : Return "June"
		Case 7 : Return "July"
		Case 8 : Return "August"
		Case 9 : Return "September"
		Case 10 : Return "October"
		Case 11 : Return "November"
		Case 12 : Return "December"
		Case Else : Return ""
	End Select
End Sub

Private Sub GetMapString(m As Map, key As String, defaultValue As String) As String
	If m.ContainsKey(key) Then Return "" & m.Get(key)
	Return defaultValue
End Sub

Private Sub GetMapLong(m As Map, key As String, defaultValue As Long) As Long
	If m.ContainsKey(key) = False Then Return defaultValue
	Try
		Return m.Get(key)
	Catch
		Return defaultValue
	End Try
End Sub

Private Sub dayLbl_Click
	Dim l As Label = Sender
	SelectedDateTicks = l.Tag
	RenderCalendar
	RenderEventsForSelectedDate
End Sub

Private Sub btnPrev_Click
	CurrentMonthTicks = StartOfMonth(AddMonths(CurrentMonthTicks, -1))
	RenderCalendar
	RenderEventsForSelectedDate
End Sub

Private Sub btnNext_Click
	CurrentMonthTicks = StartOfMonth(AddMonths(CurrentMonthTicks, 1))
	RenderCalendar
	RenderEventsForSelectedDate
End Sub

Private Sub chipSuccess_Click
	ShowSuccess = Not(ShowSuccess)
	RefreshFilterChipStyles
	RenderCalendar
	RenderEventsForSelectedDate
End Sub

Private Sub chipPending_Click
	ShowPending = Not(ShowPending)
	RefreshFilterChipStyles
	RenderCalendar
	RenderEventsForSelectedDate
End Sub

Private Sub chipDelayed_Click
	ShowDelayed = Not(ShowDelayed)
	RefreshFilterChipStyles
	RenderCalendar
	RenderEventsForSelectedDate
End Sub

Private Sub chipInProgress_Click
	ShowInProgress = Not(ShowInProgress)
	RefreshFilterChipStyles
	RenderCalendar
	RenderEventsForSelectedDate
End Sub

Private Sub lblDashboard_Click
	StartActivity(dashboard)
End Sub

Private Sub lblToDo_Click
	StartActivity(todo)
End Sub

Private Sub lblNotifs_Click
	StartActivity(notifs)
End Sub

Private Sub lblCalendar_Click
End Sub

Sub ResetNavColors
	lblDashboard.TextColor = Colors.Gray
	lblCalendar.TextColor = Colors.Gray
	lblToDo.TextColor = Colors.Gray
	lblNotifs.TextColor = Colors.Gray
End Sub

Private Sub StartOfMonth(t As Long) As Long
	Return BuildDateTicks(DateTime.GetYear(t), DateTime.GetMonth(t), 1)
End Sub

Private Sub AddMonths(t As Long, monthsToAdd As Int) As Long
	Dim y As Int = DateTime.GetYear(t)
	Dim m As Int = DateTime.GetMonth(t)
	Dim d As Int = DateTime.GetDayOfMonth(t)

	Dim total As Int = (y * 12 + (m - 1)) + monthsToAdd
	Dim ny As Int = Floor(total / 12)
	Dim nm As Int = (total Mod 12) + 1

	Dim maxD As Int = DaysInMonth(ny, nm)
	If d > maxD Then d = maxD

	Return BuildDateTicks(ny, nm, d)
End Sub

Private Sub DaysInMonth(y As Int, m As Int) As Int
	Dim ny As Int = y
	Dim nm As Int = m + 1
	If nm = 13 Then
		nm = 1
		ny = y + 1
	End If

	Dim a As Long = BuildDateTicks(y, m, 1)
	Dim b As Long = BuildDateTicks(ny, nm, 1)
	Return Round((b - a) / DateTime.TicksPerDay)
End Sub

Private Sub BuildDateTicks(y As Int, m As Int, d As Int) As Long
	Dim oldFmt As String = DateTime.DateFormat
	DateTime.DateFormat = "yyyy-MM-dd"
	Dim t As Long = DateTime.DateParse(y & "-" & Pad2(m) & "-" & Pad2(d))
	DateTime.DateFormat = oldFmt
	Return t
End Sub

Private Sub Pad2(v As Int) As String
	If v < 10 Then Return "0" & v
	Return v
End Sub

Private Sub IsSameDate(a As Long, b As Long) As Boolean
	Return DateTime.GetYear(a) = DateTime.GetYear(b) _
        And DateTime.GetMonth(a) = DateTime.GetMonth(b) _
        And DateTime.GetDayOfMonth(a) = DateTime.GetDayOfMonth(b)
End Sub