﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes
    #FullScreen: False
    #IncludeTitle: False
#End Region

Sub Process_Globals
End Sub

Sub Globals
	Private lblBack As Label
	Private Label1 As Label
	Private Label10 As Label
	Private Label11 As Label
	Private Label12 As Label
	Private Label13 As Label
	Private Label14 As Label
	Private Label15 As Label
	Private Label16 As Label
	Private Label2 As Label
	Private Label3 As Label
	Private Label4 As Label
	Private Label5 As Label
	Private Label6 As Label
	Private Label7 As Label
	Private Label8 As Label
	Private Label9 As Label
	Private Panel1 As Panel
	Private Panel2 As Panel
	Private Panel3 As Panel
	Private Panel4 As Panel
	Private Panel5 As Panel
	Private Panel6 As Panel
	Private Panel7 As Panel
	Private Panel8 As Panel
	Private Panel9 As Panel
	Private ProgressBar1 As ProgressBar

	Private CurrentProjectId As Int = 1
	Private TaskStatuses(4) As String
	Private TaskNames(4) As String
	Private TaskDueDays(4) As Int
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("project")
	InitializeTaskState
	LoadProject(CurrentProjectId)
End Sub

Sub Activity_Resume
End Sub

Sub Activity_Pause (UserClosed As Boolean)
End Sub

'Called by dashboard: CallSub2(project, "SetProjectId", projectId)
Public Sub SetProjectId(ProjectId As Int)
	CurrentProjectId = ProjectId
	If Activity.IsInitialized Then
		LoadProject(CurrentProjectId)
	End If
End Sub

Private Sub InitializeTaskState
	For i = 0 To 3
		TaskStatuses(i) = "todo"
		TaskNames(i) = "Mini Task"
		TaskDueDays(i) = 0
	Next
End Sub

Private Sub LoadProject(ProjectId As Int)
	Select ProjectId
		Case 1
			ApplyProjectData( _
                "Executioner Mobile App", _
                "Build sign up, dashboard, project details, and status tracking.", _
                Array As String("Wire signup flow", "Design dashboard cards", "Project detail UI", "Connect API"), _
                Array As Int(2, 4, 6, 8), _
                Array As String("done", "doing", "todo", "todo"))

		Case 2
			ApplyProjectData( _
                "Calendar Module", _
                "Create event lists, reminders, and due-date views.", _
                Array As String("Monthly view", "Event editor", "Reminder trigger", "Sync tasks"), _
                Array As Int(1, 3, 5, 7), _
                Array As String("doing", "todo", "todo", "todo"))

		Case 3
			ApplyProjectData( _
                "To-Do Module", _
                "Implement task creation, filtering, and quick status updates.", _
                Array As String("Task CRUD", "Filter chips", "Priorities", "Search"), _
                Array As Int(2, 2, 4, 5), _
                Array As String("done", "done", "doing", "todo"))

		Case 4
			ApplyProjectData( _
                "Notifications Module", _
                "Deliver reminders and project update alerts.", _
                Array As String("Push setup", "In-app center", "Unread badges", "Mute settings"), _
                Array As Int(3, 4, 6, 9), _
                Array As String("todo", "todo", "doing", "todo"))

		Case Else
			ApplyProjectData( _
                "Project " & ProjectId, _
                "No description yet.", _
                Array As String("Mini Task 1", "Mini Task 2", "Mini Task 3", "Mini Task 4"), _
                Array As Int(0, 0, 0, 0), _
                Array As String("todo", "todo", "todo", "todo"))
	End Select

	RefreshUI
End Sub

Private Sub ApplyProjectData(Title As String, Desc As String, Names() As String, Due() As Int, Statuses() As String)
	Label1.Text = Title
	Label2.Text = Desc

	For i = 0 To 3
		TaskNames(i) = Names(i)
		TaskDueDays(i) = Due(i)
		TaskStatuses(i) = Statuses(i).ToLowerCase
	Next
End Sub

Private Sub RefreshUI
	'Left column mini task labels
	Label3.Text = TaskNames(0)
	Label5.Text = TaskNames(1)
	Label6.Text = TaskNames(2)
	Label15.Text = TaskNames(3)

	'Middle column due labels
	Label7.Text = BuildDueText(TaskDueDays(0))
	Label8.Text = BuildDueText(TaskDueDays(1))
	Label9.Text = BuildDueText(TaskDueDays(2))
	Label14.Text = BuildDueText(TaskDueDays(3))

	'Right column status labels
	ApplyStatusToLabel(Label10, TaskStatuses(0))
	ApplyStatusToLabel(Label12, TaskStatuses(1))
	ApplyStatusToLabel(Label13, TaskStatuses(2))
	ApplyStatusToLabel(Label16, TaskStatuses(3))

	UpdateProgress
End Sub

Private Sub BuildDueText(Days As Int) As String
	If Days <= 0 Then Return "No deadline"
	Return "Due in " & Days & " days"
End Sub

Private Sub ApplyStatusToLabel(lbl As Label, Status As String)
	Select Status
		Case "todo"
			lbl.Text = "To Do"
			lbl.TextColor = Colors.RGB(120, 120, 120)
		Case "doing"
			lbl.Text = "Doing"
			lbl.TextColor = Colors.RGB(0, 121, 191)
		Case "done"
			lbl.Text = "Done"
			lbl.TextColor = Colors.RGB(46, 125, 50)
		Case Else
			lbl.Text = "To Do"
			lbl.TextColor = Colors.RGB(120, 120, 120)
	End Select
End Sub

Private Sub NextStatus(Current As String) As String
	Select Current
		Case "todo"
			Return "doing"
		Case "doing"
			Return "done"
		Case Else
			Return "todo"
	End Select
End Sub

Private Sub UpdateProgress
	Dim doneCount As Int = 0
	For i = 0 To 3
		If TaskStatuses(i) = "done" Then doneCount = doneCount + 1
	Next

	Dim percent As Int = Round((doneCount / 4) * 100)
	ProgressBar1.Progress = percent
	Label4.Text = percent & "%"
End Sub

Private Sub ToggleTaskStatus(TaskIndex As Int)
	TaskStatuses(TaskIndex) = NextStatus(TaskStatuses(TaskIndex))
	RefreshUI
End Sub

Private Sub Label10_Click
	ToggleTaskStatus(0)
End Sub

Private Sub Label12_Click
	ToggleTaskStatus(1)
End Sub

Private Sub Label13_Click
	ToggleTaskStatus(2)
End Sub

Private Sub Label16_Click
	ToggleTaskStatus(3)
End Sub

Private Sub lblBack_Click
	Activity.Finish
End Sub